"""Extract note/chord sequences from MIDI files using music21."""
import glob
import pickle
from music21 import converter, instrument, note, chord

notes = []
files = glob.glob("midi_songs/*.mid") + glob.glob("midi_songs/*.midi")
assert files, "No MIDI files found in midi_songs/"

for i, file in enumerate(files, 1):
    print(f"[{i}/{len(files)}] parsing {file}")
    try:
        midi = converter.parse(file)
    except Exception as e:
        print("  skipped:", e)
        continue
    parts = instrument.partitionByInstrument(midi)
    elements = parts.parts[0].recurse() if parts else midi.flat.notes
    for el in elements:
        if isinstance(el, note.Note):
            notes.append(str(el.pitch))
        elif isinstance(el, chord.Chord):
            notes.append(".".join(str(n) for n in el.normalOrder))

with open("notes.pkl", "wb") as f:
    pickle.dump(notes, f)
print(f"Saved {len(notes)} notes/chords, {len(set(notes))} unique.")
