"""Generate new music with the trained model and save as MIDI."""
import pickle
import random
import numpy as np
from tensorflow.keras.models import load_model
from music21 import stream, note, chord, instrument

SEQ_LEN, N_GEN, TEMPERATURE = 100, 300, 0.8

notes = pickle.load(open("notes.pkl", "rb"))
vocab = pickle.load(open("vocab.pkl", "rb"))
n_vocab = len(vocab)
note_to_int = {n: i for i, n in enumerate(vocab)}
model = load_model("model.keras")

def sample(probs, temp):
    probs = np.log(probs + 1e-9) / temp
    probs = np.exp(probs) / np.sum(np.exp(probs))
    return np.random.choice(len(probs), p=probs)

start = random.randint(0, len(notes) - SEQ_LEN - 1)
pattern = [note_to_int[n] for n in notes[start:start + SEQ_LEN]]
output = []
for _ in range(N_GEN):
    x = np.reshape(pattern, (1, SEQ_LEN, 1)) / float(n_vocab)
    idx = sample(model.predict(x, verbose=0)[0], TEMPERATURE)
    output.append(vocab[idx])
    pattern = pattern[1:] + [idx]

offset, out_notes = 0, []
for p in output:
    if "." in p or p.isdigit():
        c = chord.Chord([note.Note(int(i)) for i in p.split(".")])
        c.offset = offset
        c.storedInstrument = instrument.Piano()
        out_notes.append(c)
    else:
        nt = note.Note(p)
        nt.offset = offset
        nt.storedInstrument = instrument.Piano()
        out_notes.append(nt)
    offset += 0.5

stream.Stream(out_notes).write("midi", fp="generated_music.mid")
print("Saved generated_music.mid")
