"""Train an LSTM to predict the next note."""
import pickle
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, Activation
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import ModelCheckpoint

SEQ_LEN = 100
EPOCHS = 50
BATCH = 64

notes = pickle.load(open("notes.pkl", "rb"))
vocab = sorted(set(notes))
note_to_int = {n: i for i, n in enumerate(vocab)}
n_vocab = len(vocab)

X, y = [], []
for i in range(len(notes) - SEQ_LEN):
    X.append([note_to_int[n] for n in notes[i:i + SEQ_LEN]])
    y.append(note_to_int[notes[i + SEQ_LEN]])
n = len(X)
X = np.reshape(X, (n, SEQ_LEN, 1)) / float(n_vocab)
y = to_categorical(y, num_classes=n_vocab)

model = Sequential([
    LSTM(256, input_shape=(SEQ_LEN, 1), return_sequences=True),
    Dropout(0.3),
    LSTM(256),
    Dense(256), Dropout(0.3),
    Dense(n_vocab), Activation("softmax"),
])
model.compile(loss="categorical_crossentropy", optimizer="rmsprop")

pickle.dump(vocab, open("vocab.pkl", "wb"))
ckpt = ModelCheckpoint("model.keras", monitor="loss", save_best_only=True, verbose=1)
model.fit(X, y, epochs=EPOCHS, batch_size=BATCH, callbacks=[ckpt])
