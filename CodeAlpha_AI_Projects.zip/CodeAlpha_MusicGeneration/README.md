# CodeAlpha_MusicGeneration
LSTM that learns note patterns from MIDI files and composes new music.

## Steps
1. Put `.mid` files in `midi_songs/` (use one style, e.g. classical piano; 50+ songs works well).
2. `pip install -r requirements.txt`
3. `python preprocess.py`  - extract notes/chords with music21
4. `python train.py`       - train the 2-layer LSTM (use a GPU or Google Colab)
5. `python generate.py`    - writes `generated_music.mid`

Play the MIDI in any player, or convert to audio: `fluidsynth -ni soundfont.sf2 generated_music.mid -F out.wav`.
