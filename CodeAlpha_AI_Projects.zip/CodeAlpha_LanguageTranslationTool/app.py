"""CodeAlpha Task 1 - Language Translation Tool (Streamlit)."""
import io
import streamlit as st
from deep_translator import GoogleTranslator
from gtts import gTTS

st.set_page_config(page_title="Language Translator", page_icon="🌐")
st.title("🌐 Language Translation Tool")

LANGS = GoogleTranslator().get_supported_languages(as_dict=True)  # {'english': 'en', ...}
names = sorted(LANGS)

col1, col2 = st.columns(2)
src = col1.selectbox("From", ["auto-detect"] + names, index=0)
tgt = col2.selectbox("To", names, index=names.index("spanish"))

text = st.text_area("Enter text", height=150, placeholder="Type or paste text here...")

if st.button("Translate", type="primary"):
    if not text.strip():
        st.warning("Please enter some text.")
    else:
        try:
            src_code = "auto" if src == "auto-detect" else LANGS[src]
            result = GoogleTranslator(source=src_code, target=LANGS[tgt]).translate(text)
            st.session_state["result"] = result
            st.session_state["tgt_code"] = LANGS[tgt]
        except Exception as e:
            st.error(f"Translation failed: {e}")

if "result" in st.session_state:
    st.subheader("Translation")
    st.code(st.session_state["result"], language=None)  # hover icon = copy button
    if st.button("🔊 Listen"):
        try:
            buf = io.BytesIO()
            gTTS(st.session_state["result"], lang=st.session_state["tgt_code"]).write_to_fp(buf)
            st.audio(buf.getvalue(), format="audio/mp3")
        except Exception as e:
            st.error(f"Text-to-speech not available for this language: {e}")
