# CodeAlpha_LanguageTranslationTool
Translate text between 100+ languages with a clean Streamlit UI.

**Features:** source/target selection, auto-detect, copy button, text-to-speech.
**API:** Google Translate via `deep-translator` (no API key needed). Optional: swap in Microsoft Translator.

## Run
```
pip install -r requirements.txt
streamlit run app.py
```
