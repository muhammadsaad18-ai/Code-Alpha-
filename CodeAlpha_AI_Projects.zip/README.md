# CodeAlpha AI Internship Projects
Upload each folder as its own GitHub repo, named exactly as the folder (CodeAlpha_ProjectName).
