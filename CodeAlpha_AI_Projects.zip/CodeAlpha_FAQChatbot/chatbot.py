"""FAQ matching engine: NLTK preprocessing + TF-IDF + cosine similarity."""
import json
import string
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

for pkg in ["punkt", "punkt_tab", "stopwords", "wordnet"]:
    nltk.download(pkg, quiet=True)

STOP = set(stopwords.words("english"))
LEMMA = WordNetLemmatizer()


def preprocess(text: str) -> str:
    tokens = word_tokenize(text.lower())
    tokens = [LEMMA.lemmatize(t) for t in tokens
              if t not in string.punctuation and t not in STOP]
    return " ".join(tokens)


class FAQBot:
    def __init__(self, path="faqs.json", threshold=0.2):
        with open(path, encoding="utf-8") as f:
            self.faqs = json.load(f)
        self.threshold = threshold
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2))
        self.matrix = self.vectorizer.fit_transform(
            [preprocess(q["question"]) for q in self.faqs])

    def reply(self, user_text: str):
        vec = self.vectorizer.transform([preprocess(user_text)])
        scores = cosine_similarity(vec, self.matrix)[0]
        best = scores.argmax()
        if scores[best] < self.threshold:
            return "Sorry, I couldn't find an answer to that. Try rephrasing or contact support.", float(scores[best])
        return self.faqs[best]["answer"], float(scores[best])


if __name__ == "__main__":  # simple CLI chat
    bot = FAQBot()
    print("FAQ Bot (type 'quit' to exit)")
    while (q := input("You: ").strip().lower()) not in {"quit", "exit"}:
        print("Bot:", bot.reply(q)[0])
