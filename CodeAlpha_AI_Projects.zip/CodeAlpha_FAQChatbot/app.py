"""Streamlit chat UI for the FAQ chatbot."""
import streamlit as st
from chatbot import FAQBot

st.set_page_config(page_title="FAQ Chatbot", page_icon="💬")
st.title("💬 FAQ Chatbot")

@st.cache_resource
def load_bot():
    return FAQBot()

bot = load_bot()
if "history" not in st.session_state:
    st.session_state.history = [("assistant", "Hi! Ask me anything about orders, payments, shipping or returns.")]

for role, msg in st.session_state.history:
    st.chat_message(role).write(msg)

if prompt := st.chat_input("Type your question..."):
    st.session_state.history.append(("user", prompt))
    answer, score = bot.reply(prompt)
    st.session_state.history.append(("assistant", answer))
    st.rerun()
