# CodeAlpha_FAQChatbot
Answers questions by matching them to the closest FAQ.

**Pipeline:** NLTK (tokenize, stopword removal, lemmatize) -> TF-IDF -> cosine similarity -> best answer (with a confidence threshold).
Edit `faqs.json` to use your own topic.

## Run
```
pip install -r requirements.txt
streamlit run app.py      # chat UI
python chatbot.py         # command-line version
```
