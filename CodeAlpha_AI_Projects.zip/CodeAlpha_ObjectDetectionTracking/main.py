"""Real-time object detection (YOLOv8) + tracking (Deep SORT)."""
import argparse
import cv2
from ultralytics import YOLO
from deep_sort_realtime.deepsort_tracker import DeepSort

parser = argparse.ArgumentParser()
parser.add_argument("--source", default="0", help="0 for webcam, or path to a video file")
parser.add_argument("--conf", type=float, default=0.4)
parser.add_argument("--save", default="", help="optional output video path, e.g. output.mp4")
args = parser.parse_args()

model = YOLO("yolov8n.pt")  # downloads automatically on first run
tracker = DeepSort(max_age=30)

src = int(args.source) if args.source.isdigit() else args.source
cap = cv2.VideoCapture(src)
assert cap.isOpened(), f"Could not open source: {args.source}"

writer = None
if args.save:
    w, h = int(cap.get(3)), int(cap.get(4))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    writer = cv2.VideoWriter(args.save, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))

while True:
    ok, frame = cap.read()
    if not ok:
        break

    result = model(frame, verbose=False)[0]
    detections = []
    for box in result.boxes:
        conf = float(box.conf[0])
        if conf < args.conf:
            continue
        x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
        label = model.names[int(box.cls[0])]
        detections.append(([x1, y1, x2 - x1, y2 - y1], conf, label))

    for track in tracker.update_tracks(detections, frame=frame):
        if not track.is_confirmed():
            continue
        x1, y1, x2, y2 = map(int, track.to_ltrb())
        text = f"ID {track.track_id} {track.get_det_class()}"
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(frame, text, (x1, max(y1 - 8, 15)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    cv2.imshow("Object Detection & Tracking (press q to quit)", frame)
    if writer:
        writer.write(frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
if writer:
    writer.release()
cv2.destroyAllWindows()
