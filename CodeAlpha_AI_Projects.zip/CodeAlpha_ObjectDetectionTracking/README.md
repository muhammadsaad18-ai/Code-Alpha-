# CodeAlpha_ObjectDetectionTracking
Real-time object detection with **YOLOv8** and multi-object tracking with **Deep SORT**. Each object gets a label and a persistent tracking ID.

## Run
```
pip install -r requirements.txt
python main.py                              # webcam
python main.py --source video.mp4 --save output.mp4
```
Press `q` to quit.
